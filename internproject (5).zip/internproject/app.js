const express = require('express');
const app = express();
const bp = require('body-parser')
const ejs = require('ejs');
var mysql = require('mysql');
var session = require('express-session');

var multer = require('multer');

const DIR = './public/uploads';
var newaccesss='False';
app.use(bp.urlencoded({
  extended: true
}));

let storage = multer.diskStorage({
  destination: function(req, file, callback) {
    callback(null, DIR);
  },
  filename: function(req, file, cb) {
    var d = JSON.stringify(new Date().toISOString().replace(/T/, '').replace(/\..+/, ''));
    cb(null, file.originalname);
    console.log(file.originalname);
  }
});

let upload = multer({
  storage: storage
});


var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'mydb'
});

app.use(session({
  secret: 'secret',
  resave: true,
  saveUninitialized: true
}));

app.set("view engine", "ejs");

app.use(express.static("public"));
app.get("/", function(req, res) {
  res.render('empsignup');


});

app.get("/empsignup", function(req, res) {
  res.render("empsignup");
});


app.get("/emplogin", function(req, res) {
  res.render("emplogin");
});

app.post("/empauth", (req, resp) => {
  var user=req.body.user;
  var password = req.body.password;
  var email = req.body.email;
  if (password && email && user)  {
    connection.query('SELECT * FROM user WHERE email= ? AND password = ? AND usertype=?', [email, password,user], function(error, result, fields) {
      if (result.length > 0) {
        if(user=='admin')
        {
          resp.render("dispprogress",{user:user});
        }
        if(user=='customer')

        {
         var sql1="SELECT supercustomer FROM user WHERE email='"+email+"' AND usertype='customer'";
         connection.query(sql1,function(err,result1,filelds){
           console.log(result1[0].supercustomer)
           if(result1[0].supercustomer=='no')
           {
            resp.render("dispcompleted",{user:user});
           }
           if(result1[0].supercustomer=='yes')
           {
            resp.render("dispcomplaint",{user:user});
           }

         });
        }
        
      } else {
        resp.send("<h1><center>You are not a registered employee</center></h1>");
      }
    });
  } else {
    resp.send('Please enter Username and Password!');
    resp.end();
  }
});
app.post("/approval",(req,resp)=>{
var ema=req.body.email;
var sql1="SELECT usertype,supercustomer FROM user WHERE email='"+ema+"'";
connection.query(sql1,function(err,result1,fields){
  if(result1.length>0)
  {
  if(result1[0].usertype=='admin')
  {
    resp.send("<h1><center>Access is already set for Admin</center></h1>")
  }
  else if(result1[0].supercustomer=='yes')
  {
    resp.send("<h1><center>This customer already has access red permission</center></h1>")
  }
  else{
    var sql="UPDATE user SET supercustomer='yes' WHERE email='"+ema+"' AND usertype='customer'";
    connection.query(sql,function(err,result,fields)
    {
    if(err)
    {
    console.log(err);
    }
    else
    {
      resp.render("a");
    }
    
    });
    
  }
}
else{
  resp.send("<h1><center>user doesnt exist<center><h1>");
}
});




});
app.post("/noapproval",(req,resp)=>{
  var ema=req.body.email;
  var sql1="SELECT usertype,supercustomer FROM user WHERE email='"+ema+"'";
  connection.query(sql1,function(err,result1,fields){
    if(result1.length>0)
    {
    if(result1[0].usertype=='admin')
    {
      resp.send("<h1><center>Access red permission is already set for Admin</center></h1>")
    }
    else if(result1[0].supercustomer=='no')
    {
      resp.send("<h1><center>Access red permission is already removed for this customer</center></h1>")
    }
    else{
      var sql="UPDATE user SET supercustomer='no' WHERE email='"+ema+"' AND usertype='customer'";
      connection.query(sql,function(err,result,fields)
      {
      if(err)
      {
      console.log(err);
      }
      else
      {
        resp.render("b");
      }
      
      });
      
    }
  }
  else{
    resp.send("<h1><center>user doesnt exist<center><h1>");
  }
  });
  
  
  
  
  });
  


app.get("/noapproval",(req,resp)=>{
newaccesss='False';
  resp.render("b");

});

app.post("/empauth1", (req, resp) => {
  var user=req.body.user;
  var password = req.body.password;
  var email = req.body.email;
  if (password && email && user) {
    
    var sql = "INSERT INTO user (email,password,usertype) VALUES (?,?,?)";
    connection.query(sql,[email,password,user], function(error, results, fields) {
      if (error) {
        console.log(error);
        //resp.redirect("/failure")
        resp.send("<h1></center>Email already exists</center></h1>")
      } else {
        resp.render('emplogin');
      }
      resp.end();
    });
   
  } else {
    resp.send('Please enter all credentials!');
    resp.end();
  }
});


const port= 8080||process.env.PORT;
app.listen(port, function() {
  console.log("Started");
});
